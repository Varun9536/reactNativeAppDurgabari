const CsvLinks = {
    food : "https://docs.google.com/spreadsheets/d/1htIvm1rJ1Mv4fHvCc7wekCLmkg8evfftPuM9ho4QaHc/export?format=csv&gid=1544254778" ,
    program : "https://docs.google.com/spreadsheets/d/1htIvm1rJ1Mv4fHvCc7wekCLmkg8evfftPuM9ho4QaHc/export?format=csv&gid=1709039284" ,
    puja : "https://docs.google.com/spreadsheets/d/1htIvm1rJ1Mv4fHvCc7wekCLmkg8evfftPuM9ho4QaHc/export?format=csv&gid=0" ,
    //  puja : "https://docs.google.com/spreadsheets/d/1htIvm1rJ1Mv4fHvCc7wekCLmkg8evfftPuM9ho4QaHc/export?format=csv&gid=1544254778" ,
    transport : "https://docs.google.com/spreadsheets/d/1htIvm1rJ1Mv4fHvCc7wekCLmkg8evfftPuM9ho4QaHc/export?format=csv&gid=476184183" 
   
}

export default CsvLinks